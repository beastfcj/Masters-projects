INSERT INTO Vehicles (VehicleID, Make, Model, Year, VehicleType, RegistrationNumber, CurrentMileage)
VALUES
(1, 'Toyota', 'Camry', 2020, 'Sedan', 'ABC123', 30000),
(2, 'Honda', 'Civic', 2019, 'Sedan', 'XYZ789', 25000);
-- Add more vehicle data as needed

-- Inserting data into Customers table
INSERT INTO Customers (CustomerID, FirstName, LastName, Email, PhoneNumber)
VALUES
(1, 'John', 'Doe', 'john.doe@example.com', '555-1234'),
(2, 'Jane', 'Smith', 'jane.smith@example.com', '555-5678');
-- Add more customer data as needed

-- Inserting data into Rentals table
INSERT INTO Rentals (RentalID, VehicleID, CustomerID, StartDate, EndDate, TotalCost)
VALUES
(1, 1, 1, '2023-01-01', '2023-01-07', 350.00),
(2, 2, 2, '2023-02-01', '2023-02-10', 300.00);
-- Add more rental data as needed

-- Inserting data into Pricing table
INSERT INTO Pricing (PricingID, VehicleType, DailyRate)
VALUES
(1, 'Sedan', 50.00),
(2, 'SUV', 70.00);
-- Add more pricing data as needed

-- Inserting data into Locations table
INSERT INTO Locations (LocationID, Address, City, State, ZipCode)
VALUES
(1, '123 Main St', 'Cityville', 'CA', '90001'),
(2, '456 Oak St', 'Townburg', 'NY', '10001');
-- Add more location data as needed
-- Inserting data into Maintenance table
INSERT INTO Maintenance (MaintenanceID, VehicleID, Date, Description, Cost)
VALUES
(1, 1, '2023-03-01', 'Oil Change', 50.00),
(2, 2, '2023-04-01', 'Brake Inspection', 80.00);
-- Add more maintenance data as needed

-- Inserting data into Employees table
INSERT INTO Employees (EmployeeID, FirstName, LastName, Position, Email, PhoneNumber)
VALUES
(1, 'Alice', 'Johnson', 'Manager', 'alice.johnson@example.com', '555-1111'),
(2, 'Bob', 'Williams', 'Technician', 'bob.williams@example.com', '555-2222');
-- Add more employee data as needed

-- Inserting data into Feedback table
INSERT INTO Feedback (FeedbackID, CustomerID, Date, Comment, Rating)
VALUES
(1, 1, '2023-05-01', 'Great service!', 5),
(2, 2, '2023-06-01', 'Vehicle was clean and in good condition', 4);
-- Add more feedback data as needed