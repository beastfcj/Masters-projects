-- Query1
SELECT
    C.FirstName,
    C.LastName,
    R.StartDate,
    R.EndDate,
    V.Make,
    V.Model
FROM
    Customers C
JOIN
    Rentals R ON C.CustomerID = R.CustomerID
JOIN
    Vehicles V ON R.VehicleID = V.VehicleID
WHERE
    R.StartDate BETWEEN '2023-01-01' AND '2023-01-31';
-- Query 2
SELECT
    C.FirstName,
    C.LastName,
    SUM(R.TotalCost) AS TotalSpent
FROM
    Customers C
JOIN
    Rentals R ON C.CustomerID = R.CustomerID
GROUP BY
    C.CustomerID
ORDER BY
    TotalSpent DESC
LIMIT 3;

-- Query 3


-- Query random trigger
-- Update example
UPDATE Vehicles SET CurrentMileage = 35000 WHERE VehicleID = 1;

-- Insert example
INSERT INTO Rentals (RentalID, VehicleID, CustomerID, StartDate, EndDate, TotalCost)
VALUES (3, 1, 1, '2023-05-01', '2023-05-05', 250.00);

-- Check the UpdateLog table
SELECT * FROM UpdateLog;

DROP TRIGGER trg_after_update_vehicle;
DROP TRIGGER trg_after_insert_rental;