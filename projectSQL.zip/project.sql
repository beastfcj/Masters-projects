-- Creating table: Vehicles
CREATE TABLE Vehicles (
    VehicleID INT PRIMARY KEY,
    Make VARCHAR(50),
    Model VARCHAR(50),
    Year INT,
    VehicleType VARCHAR(50),
    RegistrationNumber VARCHAR(20),
    CurrentMileage INT
);

-- Creating table: Customers
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Email VARCHAR(100),
    PhoneNumber VARCHAR(20)
);

-- Creating table: Rentals
CREATE TABLE Rentals (
    RentalID INT PRIMARY KEY,
    VehicleID INT,
    CustomerID INT,
    StartDate DATE,
    EndDate DATE,
    TotalCost DECIMAL(10, 2),
    FOREIGN KEY (VehicleID) REFERENCES Vehicles(VehicleID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Creating table: Pricing
CREATE TABLE Pricing (
    PricingID INT PRIMARY KEY,
    VehicleType VARCHAR(50),
    DailyRate DECIMAL(10, 2)
);

-- Creating table: Locations
CREATE TABLE Locations (
    LocationID INT PRIMARY KEY,
    Address VARCHAR(255),
    City VARCHAR(50),
    State VARCHAR(50),
    ZipCode VARCHAR(10)
);

-- Creating table: Maintenance
CREATE TABLE Maintenance (
    MaintenanceID INT PRIMARY KEY,
    VehicleID INT,
    Date DATE,
    Description VARCHAR(255),
    Cost DECIMAL(10, 2),
    FOREIGN KEY (VehicleID) REFERENCES Vehicles(VehicleID)
);

-- Creating table: Employees
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Position VARCHAR(50),
    Email VARCHAR(100),
    PhoneNumber VARCHAR(20)
);

-- Creating table: Feedback
CREATE TABLE Feedback (
    FeedbackID INT PRIMARY KEY,
    CustomerID INT,
    Date DATE,
    Comment TEXT,
    Rating INT,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Creating table: UpdateLog
CREATE TABLE UpdateLog (
    LogID INT PRIMARY KEY,
    TableName VARCHAR(50),
    RecordID INT,
    ActionType VARCHAR(10),
    LogDate DATETIME DEFAULT CURRENT_TIMESTAMP
);

DELIMITER //

-- Trigger for Updates
CREATE TRIGGER trg_after_update_vehicle
BEFORE UPDATE ON Vehicles
FOR EACH ROW
BEGIN
    -- Update the CurrentMileage
    UPDATE Vehicles
    SET CurrentMileage = NEW.CurrentMileage
    WHERE VehicleID = NEW.VehicleID;

    -- Insert a row into the UpdateLog table
    INSERT INTO UpdateLog (TableName, RecordID, ActionType)
    VALUES ('Vehicles', NEW.VehicleID, 'UPDATE');
END;//

-- Reset the delimiter to the default
DELIMITER ;

DELIMITER //
-- Trigger for Logging
CREATE TRIGGER trg_after_insert_rental
BEFORE INSERT ON Rentals
FOR EACH ROW
BEGIN
    -- Insert a row into the UpdateLog table
    INSERT INTO UpdateLog (TableName, RecordID, ActionType)
    VALUES ('Rentals', NEW.RentalID, 'INSERT');
END;//

-- Reset the delimiter to the default
DELIMITER ;


